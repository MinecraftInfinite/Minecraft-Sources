package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.RailShape;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRail extends BlockRailBase {
   public static final EnumProperty<RailShape> SHAPE = BlockStateProperties.RAIL_SHAPE;

   protected BlockRail(Block.Properties builder) {
      super(false, builder);
      this.setDefaultState((IBlockState)(this.stateContainer.getBaseState()).with(SHAPE, RailShape.NORTH_SOUTH));
   }

   protected void updateState(IBlockState state, World worldIn, BlockPos pos, Block blockIn) {
      if (blockIn.getDefaultState().canProvidePower() && (new BlockRailState(worldIn, pos, state)).countAdjacentRails() == 3) {
         this.func_208489_a(worldIn, pos, state, false);
      }

   }

   public IProperty<RailShape> getShapeProperty() {
      return SHAPE;
   }

   public IBlockState rotate(IBlockState state, Rotation rot) {
      switch(rot) {
      case CLOCKWISE_180:
         switch((RailShape)state.get(SHAPE)) {
         case ASCENDING_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_WEST);
         case ASCENDING_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_EAST);
         case ASCENDING_NORTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_SOUTH);
         case ASCENDING_SOUTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_NORTH);
         case SOUTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_WEST);
         case SOUTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_EAST);
         case NORTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_EAST);
         case NORTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_WEST);
         }
      case COUNTERCLOCKWISE_90:
         switch((RailShape)state.get(SHAPE)) {
         case ASCENDING_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_NORTH);
         case ASCENDING_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_SOUTH);
         case ASCENDING_NORTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_WEST);
         case ASCENDING_SOUTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_EAST);
         case SOUTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_EAST);
         case SOUTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_EAST);
         case NORTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_WEST);
         case NORTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_WEST);
         case NORTH_SOUTH:
            return (IBlockState)state.with(SHAPE, RailShape.EAST_WEST);
         case EAST_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_SOUTH);
         }
      case CLOCKWISE_90:
         switch((RailShape)state.get(SHAPE)) {
         case ASCENDING_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_SOUTH);
         case ASCENDING_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_NORTH);
         case ASCENDING_NORTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_EAST);
         case ASCENDING_SOUTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_WEST);
         case SOUTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_WEST);
         case SOUTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_WEST);
         case NORTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_EAST);
         case NORTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_EAST);
         case NORTH_SOUTH:
            return (IBlockState)state.with(SHAPE, RailShape.EAST_WEST);
         case EAST_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_SOUTH);
         }
      default:
         return state;
      }
   }

   public IBlockState mirror(IBlockState state, Mirror mirrorIn) {
      RailShape railshape = (RailShape)state.get(SHAPE);
      switch(mirrorIn) {
      case LEFT_RIGHT:
         switch(railshape) {
         case ASCENDING_NORTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_SOUTH);
         case ASCENDING_SOUTH:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_NORTH);
         case SOUTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_EAST);
         case SOUTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_WEST);
         case NORTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_WEST);
         case NORTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_EAST);
         default:
            return super.mirror(state, mirrorIn);
         }
      case FRONT_BACK:
         switch(railshape) {
         case ASCENDING_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_WEST);
         case ASCENDING_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.ASCENDING_EAST);
         case ASCENDING_NORTH:
         case ASCENDING_SOUTH:
         default:
            break;
         case SOUTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_WEST);
         case SOUTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.SOUTH_EAST);
         case NORTH_WEST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_EAST);
         case NORTH_EAST:
            return (IBlockState)state.with(SHAPE, RailShape.NORTH_WEST);
         }
      }

      return super.mirror(state, mirrorIn);
   }

   protected void fillStateContainer(StateContainer.Builder<Block, IBlockState> builder) {
      builder.add(SHAPE);
   }
}
